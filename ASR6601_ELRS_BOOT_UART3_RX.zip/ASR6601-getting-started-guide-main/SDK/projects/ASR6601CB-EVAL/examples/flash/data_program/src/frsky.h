#ifndef FRSKY_H_
#define FRSKY_H_

#include <stdint.h>

int8_t frsky_check(void);

#endif /* FRSKY_H_ */
