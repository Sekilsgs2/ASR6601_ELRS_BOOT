#include <stdio.h>
#include <stdarg.h>
#include "tremo_uart.h"
#include "tremo_gpio.h"
#include "tremo_rcc.h"
#include "tremo_delay.h"

extern uint32_t systime;
void uart_log_init(void)
{
    // uart0
    gpio_set_iomux(GPIOB, GPIO_PIN_0, 1);
    gpio_set_iomux(GPIOB, GPIO_PIN_1, 1);

    /* uart config struct init */
    uart_config_t uart_config;
    uart_config_init(&uart_config);

    uart_config.baudrate = 420000;
    uart_init(CONFIG_DEBUG_UART, &uart_config);
	  uart_config_interrupt(CONFIG_DEBUG_UART,UART_INTERRUPT_RX_DONE | UART_INTERRUPT_FRAME_ERROR | UART_INTERRUPT_OVERRUN_ERROR, ENABLE);
    uart_cmd(CONFIG_DEBUG_UART, ENABLE);
}

void UART0_IRQHandler(void) {
  if ( uart_get_interrupt_status(UART0, UART_INTERRUPT_RX_DONE) )
  {
	//if (rx_callback[0])
		//rx_callback[0]();
		while (uart_get_flag_status(UART0,UART_FLAG_RX_FIFO_EMPTY) != SET)
		{
			uint8_t ch = UART0->DR;
			if (uart_get_flag_status(UART0,UART_FLAG_TX_FIFO_FULL) != SET)
				UART0->DR = ch;
			//UART0->DR = ch;
		}
    uart_clear_interrupt(UART0, UART_INTERRUPT_RX_DONE);
  }

  if ( uart_get_interrupt_status(UART0, UART_INTERRUPT_RX_TIMEOUT) )
  {
    uart_clear_interrupt(UART0, UART_INTERRUPT_RX_TIMEOUT);
  }
	
  if ( uart_get_interrupt_status(UART0, UART_INTERRUPT_OVERRUN_ERROR) )
  {
    uart_clear_interrupt(UART0, UART_INTERRUPT_OVERRUN_ERROR);
  }
	
	
  if ( uart_get_interrupt_status(UART0, UART_INTERRUPT_FRAME_ERROR) )
  {
    uart_clear_interrupt(UART0, UART_INTERRUPT_FRAME_ERROR);
  }
	
}

uint32_t GetTickCount(void)
{
	uint32_t m = systime;
	return m;
}

unsigned long micros( void )
{
    uint32_t ticks, ticks2;
    uint32_t pend, pend2;
    uint32_t count, count2;

    ticks2  = SysTick->VAL;
    pend2   = !!((SCB->ICSR & SCB_ICSR_PENDSTSET_Msk)||((SCB->SHCSR & SCB_SHCSR_SYSTICKACT_Msk)))  ;
    count2  = GetTickCount();

    do {
        ticks=ticks2;
        pend=pend2;
        count=count2;
        ticks2  = SysTick->VAL;
        pend2   = !!((SCB->ICSR & SCB_ICSR_PENDSTSET_Msk)||((SCB->SHCSR & SCB_SHCSR_SYSTICKACT_Msk)))  ;
        count2  = GetTickCount();
    } while ((pend != pend2) || (count != count2) || (ticks < ticks2));

    return ((count+pend) * 1000) + (((SysTick->LOAD  - ticks)*(1048576/(48000000/1000000)))>>20) ; 
    // this is an optimization to turn a runtime division into two compile-time divisions and 
    // a runtime multiplication and shift, saving a few cycles
}

int main(void)
{
	  system_init();
	
    rcc_enable_peripheral_clk(RCC_PERIPHERAL_UART0, true);
	  rcc_enable_peripheral_clk(RCC_PERIPHERAL_AFEC, true);
    rcc_enable_peripheral_clk(RCC_PERIPHERAL_GPIOA, true);
    rcc_enable_peripheral_clk(RCC_PERIPHERAL_GPIOB, true);
    rcc_enable_peripheral_clk(RCC_PERIPHERAL_GPIOC, true);
    rcc_enable_peripheral_clk(RCC_PERIPHERAL_GPIOD, true);
    rcc_enable_peripheral_clk(RCC_PERIPHERAL_PWR, true);
    rcc_enable_peripheral_clk(RCC_PERIPHERAL_SYSCFG, true);
    rcc_enable_peripheral_clk(RCC_PERIPHERAL_RTC, true);
    rcc_enable_peripheral_clk(RCC_PERIPHERAL_SAC, true);
    rcc_enable_peripheral_clk(RCC_PERIPHERAL_LORA, true);

    uart_log_init();
    //printf("hello world\r\n");

    /* Infinite loop */
    while (1) {

		}
}

#ifdef USE_FULL_ASSERT
void assert_failed(void* file, uint32_t line)
{
    (void)file;
    (void)line;

    while (1) { }
}
#endif
